/* XPM */
static char *minimize_xpm[] = {
/* width height num_colors chars_per_pixel */
  "    13    11       2       1",
/* colors */
  ". c #000000",
  "  c None s None",
/* pixels */
  "             ",
  "             ",
  "             ",
  "             ",
  "             ",
  "             ",
  "             ",
  "             ",
  "   ......    ",
  "   ......    ",
  "             "
};

/* XPM */
static char *maximize_xpm[] = {
/* width height num_colors chars_per_pixel */
  "    13    11       2            1",
/* colors */
  ". c #000000",
  "  c None s None",
/* pixels */
  "             ",
  "  .........  ",
  "  .........  ",
  "  .       .  ",
  "  .       .  ",
  "  .       .  ",
  "  .       .  ",
  "  .       .  ",
  "  .       .  ",
  "  .........  ",
  "             "
};

/* XPM */
static char *close_xpm[] = {
/* width height num_colors chars_per_pixel */
  "    13    11       2            1",
/* colors */
  ". c #000000",
  "  c None s None",
/* pixels */
  "             ",
  "             ",
  "   ..    ..  ",
  "    ..  ..   ",
  "     ....    ",
  "      ..     ",
  "     ....    ",
  "    ..  ..   ",
  "   ..    ..  ",
  "             ",
  "             "
};

/* XPM */
static char *sysmenu_xpm[] = {
/* width height num_colors chars_per_pixel */
  "    13    11       2       1",
/* colors */
  ". c #000000",
  "  c None s None",
/* pixels */
  "             ",
  "             ",
  "             ",
  "             ",
  "             ",
  "    .....    ",
  "    .....    ",
  "             ",
  "             ",
  "             ",
  "             "
};

/* XPM */
static char *normalize_xpm[] = {
/* width height num_colors chars_per_pixel */
  "    13     11     2     1",
/* colors */
  ". c #000000",
  "  c None s None",
/* pixels */
  "             ",
  "    ......   ",
  "    ......   ",
  "    .    .   ",
  "  ...... .   ",
  "  ...... .   ",
  "  .    ...   ",
  "  .    .     ",
  "  .    .     ",
  "  ......     ",
  "             "
};
